// ═══════════════════════════════════════════════════════════
// Mr JS — Amazon Content Script
// ═══════════════════════════════════════════════════════════
// Injected on Amazon seller storefront pages.
// Finds JungleScout UI elements, clicks scan, waits for data, downloads CSV.

if (window._mrJsAmazonInjected) {
  // Already injected
} else {
  window._mrJsAmazonInjected = true;
}

let scanTimeout = 30000;

// ── Message listener ─────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
  switch (msg.action) {

    case 'startJsScan': {
      scanTimeout = msg.timeout || 30000;
      findAndClickScanButton();
      respond({ ok: true });
      break;
    }

    case 'clickDownload': {
      findAndClickDownload();
      respond({ ok: true });
      break;
    }

    default:
      respond({ ok: false });
  }
  return true;
});

// ── Step 1: Find and click JungleScout "Scan Search Results" button ──

function findAndClickScanButton() {
  let attempts = 0;
  const maxAttempts = 30; // 30 × 500ms = 15 seconds

  const poller = setInterval(() => {
    attempts++;

    const btn = findJsElement('scan');
    if (btn) {
      clearInterval(poller);
      btn.click();
      chrome.runtime.sendMessage({ action: 'jsButtonClicked' });
      // Start watching for data to load
      waitForJsData();
      return;
    }

    if (attempts >= maxAttempts) {
      clearInterval(poller);
      chrome.runtime.sendMessage({ action: 'jsButtonNotFound' });
    }
  }, 500);
}

// ── Step 2: Wait for JungleScout data to load ────────────

function waitForJsData() {
  let attempts = 0;
  const maxAttempts = 60; // 60 × 500ms = 30 seconds

  const poller = setInterval(() => {
    attempts++;

    // Check if JS overlay has product data rows
    if (hasJsData()) {
      clearInterval(poller);
      // Small delay to let data fully render
      setTimeout(() => {
        chrome.runtime.sendMessage({ action: 'jsDataLoaded' });
      }, 1500);
      return;
    }

    if (attempts >= maxAttempts) {
      clearInterval(poller);
      chrome.runtime.sendMessage({ action: 'jsNoData' });
    }
  }, 500);
}

// ── Step 3: Find and click Download button ───────────────

function findAndClickDownload() {
  const btn = findJsElement('download');
  if (btn) {
    btn.click();
    // Small delay then notify
    setTimeout(() => {
      chrome.runtime.sendMessage({ action: 'downloadClicked' });
    }, 500);
  } else {
    chrome.runtime.sendMessage({ action: 'downloadButtonNotFound' });
  }
}

// ═══════════════════════════════════════════════════════════
// JungleScout element detection
// ═══════════════════════════════════════════════════════════
// JungleScout injects UI into Amazon pages. It may use:
// - Regular DOM elements
// - Shadow DOM
// - iframes
// We try all strategies.

function findJsElement(type) {
  // ── Regular DOM search ──
  const found = findInRegularDom(type);
  if (found) return found;

  // ── Shadow DOM search ──
  const shadowFound = findInShadowDom(type);
  if (shadowFound) return shadowFound;

  // ── iframe search ──
  const iframeFound = findInIframes(type);
  if (iframeFound) return iframeFound;

  return null;
}

function findInRegularDom(type) {
  if (type === 'scan') {
    // JungleScout scan button — floating button at bottom of page
    // Look for buttons/elements containing "Scan" text
    const allButtons = document.querySelectorAll('button, [role="button"], a, div[class*="btn"], span[class*="btn"]');
    for (const el of allButtons) {
      const txt = (el.textContent || '').trim();
      if (/scan\s*(search)?\s*results?/i.test(txt) || /scan\s*page/i.test(txt)) {
        return el;
      }
    }

    // Also check for JungleScout's known class patterns
    const jsSelectors = [
      '[class*="junglescout"] button',
      '[class*="jungle-scout"] button',
      '[id*="junglescout"] button',
      '[data-testid*="scan"]',
      // JS extension often uses specific wrapper classes
      '[class*="jsc-"] button',
      '[class*="js-scan"]',
      // The floating action button
      'button[class*="scan"]',
      'div[class*="float"] button'
    ];
    for (const sel of jsSelectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }

    // Check for SVG icon buttons (JS uses icons)
    const svgButtons = document.querySelectorAll('button svg, [role="button"] svg');
    for (const svg of svgButtons) {
      const parent = svg.closest('button') || svg.closest('[role="button"]');
      if (parent) {
        const txt = (parent.textContent || parent.getAttribute('aria-label') || '').toLowerCase();
        if (txt.includes('scan')) return parent;
      }
    }
  }

  if (type === 'download') {
    // Download button in JS overlay
    const allButtons = document.querySelectorAll('button, [role="button"], a');
    for (const el of allButtons) {
      const txt = (el.textContent || '').trim().toLowerCase();
      if (txt === 'download' || txt === 'export' || txt === 'download csv') {
        // Make sure it's in the JS overlay, not Amazon's page
        if (isJsOverlayElement(el)) return el;
      }
    }

    // Broader search — any download button that appeared after scan
    for (const el of allButtons) {
      const txt = (el.textContent || '').trim().toLowerCase();
      if (txt === 'download') return el;
    }

    // Check for download icon buttons
    const jsDownload = document.querySelector(
      '[class*="junglescout"] [class*="download"], ' +
      '[class*="jungle-scout"] button[class*="download"], ' +
      '[data-testid*="download"]'
    );
    if (jsDownload) return jsDownload;
  }

  return null;
}

function findInShadowDom(type) {
  // Walk all shadow roots
  const allElements = document.querySelectorAll('*');
  for (const el of allElements) {
    if (el.shadowRoot) {
      const found = searchShadow(el.shadowRoot, type);
      if (found) return found;
    }
  }
  return null;
}

function searchShadow(root, type) {
  const textMatch = type === 'scan' ? /scan/i : /download/i;

  const buttons = root.querySelectorAll('button, [role="button"], a');
  for (const btn of buttons) {
    const txt = (btn.textContent || '').trim();
    if (textMatch.test(txt)) {
      if (type === 'scan' && /scan\s*(search)?\s*results?/i.test(txt)) return btn;
      if (type === 'download' && /^download$/i.test(txt.trim())) return btn;
    }
  }

  // Recurse into nested shadow roots
  const nested = root.querySelectorAll('*');
  for (const el of nested) {
    if (el.shadowRoot) {
      const found = searchShadow(el.shadowRoot, type);
      if (found) return found;
    }
  }

  return null;
}

function findInIframes(type) {
  try {
    const iframes = document.querySelectorAll('iframe');
    for (const iframe of iframes) {
      try {
        const doc = iframe.contentDocument;
        if (!doc) continue;

        const textMatch = type === 'scan' ? /scan\s*(search)?\s*results?/i : /^download$/i;
        const buttons = doc.querySelectorAll('button, [role="button"], a');
        for (const btn of buttons) {
          const txt = (btn.textContent || '').trim();
          if (textMatch.test(txt)) return btn;
        }
      } catch { /* cross-origin, skip */ }
    }
  } catch {}
  return null;
}

// ── Data detection ───────────────────────────────────────

function hasJsData() {
  // Check if JungleScout's product table has loaded with actual data rows
  // The overlay shows a table with columns: Product Name, Brand, Price, etc.

  // Strategy 1: Look for JS overlay table with data rows
  const tableRows = document.querySelectorAll(
    '[class*="junglescout"] table tbody tr, ' +
    '[class*="jungle-scout"] table tbody tr, ' +
    '[class*="jsc"] table tbody tr'
  );
  if (tableRows.length > 0) return true;

  // Strategy 2: Look for product rows with price data
  // JS shows product names and prices in its overlay
  const priceElements = document.querySelectorAll('[class*="junglescout"] [class*="price"], [class*="jungle-scout"] [class*="price"]');
  if (priceElements.length > 0) return true;

  // Strategy 3: Broad search — look for the JS overlay with multiple data items
  // The overlay typically shows avg monthly sales, avg price, avg reviews, etc.
  const allText = document.body.innerText;
  if (/AVG\s*MONTHLY\s*SALES/i.test(allText) && /AVG\s*PRICE/i.test(allText)) {
    // Also check if there's at least one product row with a brand name
    // This means data has loaded (not just the header)
    const downloadBtn = findInRegularDom('download');
    if (downloadBtn) return true; // download button appears = data is ready
  }

  // Strategy 4: Check shadow DOM for data
  const allElements = document.querySelectorAll('*');
  for (const el of allElements) {
    if (el.shadowRoot) {
      const tables = el.shadowRoot.querySelectorAll('table tbody tr');
      if (tables.length > 2) return true; // more than header row

      const text = el.shadowRoot.textContent || '';
      if (/AVG\s*MONTHLY\s*SALES/i.test(text) && el.shadowRoot.querySelector('button')) {
        // Has summary stats and buttons = loaded
        const dlBtn = searchShadow(el.shadowRoot, 'download');
        if (dlBtn) return true;
      }
    }
  }

  // Strategy 5: Check if "Load more" button appeared (means at least first batch loaded)
  const loadMore = document.querySelector('button');
  for (const btn of document.querySelectorAll('button')) {
    if (/load\s*more/i.test(btn.textContent)) return true;
  }

  return false;
}

function isJsOverlayElement(el) {
  // Check if an element is part of JungleScout's overlay (not Amazon's native UI)
  let node = el;
  while (node && node !== document.body) {
    const cls = (node.className || '').toString().toLowerCase();
    const id = (node.id || '').toLowerCase();
    if (cls.includes('jungle') || cls.includes('jsc') || id.includes('jungle') || id.includes('jsc')) {
      return true;
    }
    node = node.parentElement;
  }
  // If we can't determine, assume true (better to click wrong download than miss it)
  return true;
}
