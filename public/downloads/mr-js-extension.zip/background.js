// ═══════════════════════════════════════════════════════════
// Mr JS v3 — Pipelined Batch Processing
// ═══════════════════════════════════════════════════════════
// Per batch of N links:
//   Round 1: Mark copied + Open tabs (one by one)
//   Round 2: Click JS scan button (one by one)
//   Round 3: Wait for data to load (all tabs)
//   Round 4: Click Download (one by one)
//   Round 5: Close all tabs → next batch

const INITIAL_STATE = {
  status: 'idle',
  scrappyTabId: null,

  // Config
  delay: 800,            // delay between sequential operations within a round
  jsTimeout: 30000,
  batchSize: 5,

  // All links from Scrappy
  links: [],
  nextLinkIndex: 0,
  allLinksCollected: false,

  // Current batch
  batch: [],             // [{ tabId, url, uid, phase }]
                         // phase: opened | js_clicked | data_ready | data_timeout | downloaded | download_fail
  batchPhase: 'none',    // none | opening | waiting_load | clicking_js | waiting_data | downloading | closing

  // Control
  shouldStop: false,
  errors: [],
  downloadCounter: 1,       // auto-incrementing file number
  pendingRename: null,       // expected filename for current download (e.g., "5-js")
  stats: { total: 0, processed: 0, downloaded: 0, skipped: 0 }
};

let state = { ...INITIAL_STATE };

async function save() { await chrome.storage.local.set({ mrjs: state }); }
async function load() { const d = await chrome.storage.local.get('mrjs'); if (d.mrjs) state = d.mrjs; }
load();

// ── Auto-rename downloads to {N}-js.csv ──────────────────

chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  if (!state.pendingRename) return;
  const fn = (item.filename || '').toLowerCase();
  if (fn.endsWith('.csv') || fn.includes('junglescout')) {
    suggest({ filename: `mr-js/${state.pendingRename}.csv`, conflictAction: 'uniquify' });
  }
});

// ── Message handler ──────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  (async () => {
    switch (msg.action) {
      case 'start':     await startRun(msg); respond({ ok: true }); break;
      case 'stop':      await stopRun();     respond({ ok: true }); break;
      case 'getState':  await load();        respond({ state });    break;
      case 'reset':     await resetRun();    respond({ ok: true }); break;

      // Scrappy
      case 'linksFound': {
        const existing = new Set(state.links.map(l => l.uid));
        for (const l of (msg.links || [])) {
          if (!existing.has(l.uid)) { state.links.push(l); existing.add(l.uid); }
        }
        state.stats.total = state.links.length;
        if (msg.noMore) state.allLinksCollected = true;
        await save();
        // If we're waiting for links, start the batch
        if (state.batchPhase === 'none' && state.status === 'running') {
          startNextBatch();
        }
        respond({ ok: true });
        break;
      }

      // Amazon content script signals
      case 'jsButtonClicked': {
        markBatchTab(sender.tab?.id, 'js_clicked');
        respond({ ok: true });
        break;
      }
      case 'jsDataLoaded': {
        markBatchTab(sender.tab?.id, 'data_ready');
        // Check if all tabs in batch have data (or timed out)
        if (state.batchPhase === 'waiting_data') checkAllDataReady();
        respond({ ok: true });
        break;
      }
      case 'jsButtonNotFound': {
        markBatchTab(sender.tab?.id, 'data_timeout');
        tabErr(sender.tab?.id, 'JS button not found');
        if (state.batchPhase === 'waiting_data' || state.batchPhase === 'clicking_js') checkAllDataReady();
        respond({ ok: true });
        break;
      }
      case 'jsNoData': {
        markBatchTab(sender.tab?.id, 'data_timeout');
        tabErr(sender.tab?.id, 'No data');
        if (state.batchPhase === 'waiting_data') checkAllDataReady();
        respond({ ok: true });
        break;
      }
      case 'downloadClicked': {
        markBatchTab(sender.tab?.id, 'download_pending');
        respond({ ok: true });
        break;
      }
      case 'downloadButtonNotFound': {
        markBatchTab(sender.tab?.id, 'download_fail');
        tabErr(sender.tab?.id, 'Download button not found');
        respond({ ok: true });
        break;
      }

      default: respond({ ok: false });
    }
  })();
  return true;
});

// ── Download detection: handled inline in round4 via polling ──

let closingBatch = false; // flag to suppress onRemoved during cleanup

// Handle tab closed
chrome.tabs.onRemoved.addListener(async (tabId) => {
  if (closingBatch) return; // we're closing tabs intentionally — ignore
  await load();
  const entry = state.batch.find(t => t.tabId === tabId);
  if (entry && state.status === 'running') {
    entry.phase = 'closed_external';
    entry.tabId = null;
    tabErr(tabId, 'Tab closed externally');
    await save();
  }
});

// ── Start / Stop / Reset ─────────────────────────────────

async function startRun(msg) {
  state = {
    ...INITIAL_STATE,
    status: 'running',
    scrappyTabId: msg.scrappyTabId,
    delay: msg.delay || 800,
    jsTimeout: msg.jsTimeout || 30000,
    batchSize: msg.maxParallel || 5
  };
  await save();

  try {
    await chrome.scripting.executeScript({
      target: { tabId: state.scrappyTabId },
      files: ['content-scrappy.js']
    });
    await sleep(300);
    safeSend(state.scrappyTabId, { action: 'scanLinks', batchSize: state.batchSize });
  } catch (e) {
    state.status = 'error';
    state.errors.push(`Scrappy inject: ${e.message}`);
    await save();
  }
}

async function stopRun() {
  state.shouldStop = true;
  state.status = 'stopped';
  closingBatch = true;
  for (const t of state.batch) {
    if (t.tabId) try { chrome.tabs.remove(t.tabId); } catch {}
  }
  state.batch = [];
  closingBatch = false;
  await save();
}

async function resetRun() {
  closingBatch = true;
  for (const t of (state.batch || [])) {
    if (t.tabId) try { chrome.tabs.remove(t.tabId); } catch {}
  }
  closingBatch = false;
  state = { ...INITIAL_STATE };
  await save();
}

// ═══════════════════════════════════════════════════════════
// BATCH PIPELINE
// ═══════════════════════════════════════════════════════════

async function startNextBatch() {
  await load();
  if (state.shouldStop) { state.status = 'stopped'; await save(); return; }

  // Grab next N links
  const batchLinks = state.links.slice(state.nextLinkIndex, state.nextLinkIndex + state.batchSize);

  if (batchLinks.length === 0) {
    if (state.allLinksCollected) {
      state.status = 'done';
      await save();
      return;
    }
    // Need more links — ask Scrappy to scroll
    safeSend(state.scrappyTabId, { action: 'scrollAndScan', batchSize: state.batchSize });
    return;
  }

  state.batch = batchLinks.map(l => ({
    tabId: null,
    url: l.url,
    uid: l.uid,
    phase: 'pending'
  }));
  state.nextLinkIndex += batchLinks.length;
  await save();

  // ── ROUND 1: Mark copied + Open tabs (sequential) ──
  await round1_open();
}

async function round1_open() {
  state.batchPhase = 'opening';
  await save();

  for (let i = 0; i < state.batch.length; i++) {
    if (state.shouldStop) return;
    const entry = state.batch[i];

    // Switch to Scrappy to mark as copied
    try { await chrome.tabs.update(state.scrappyTabId, { active: true }); } catch {}
    // Mark as copied on Scrappy FIRST
    safeSend(state.scrappyTabId, { action: 'clickCopyForUrl', uid: entry.uid });
    await sleep(400);

    // Open Amazon tab (active — user sees it)
    try {
      const tab = await chrome.tabs.create({ url: entry.url, active: true });
      entry.tabId = tab.id;
      entry.phase = 'opened';
      await save();
    } catch (e) {
      entry.phase = 'open_failed';
      tabErr(null, `Open failed: ${e.message}`);
    }

    // Small delay before next open
    if (i < state.batch.length - 1) await sleep(state.delay);
  }

  // ── Wait for all tabs to finish loading ──
  state.batchPhase = 'waiting_load';
  await save();
  await waitAllTabsLoaded();

  // CAPTCHA check on all tabs
  for (const entry of state.batch) {
    if (!entry.tabId || entry.phase === 'open_failed') continue;
    if (await isCaptcha(entry.tabId)) {
      tabErr(entry.tabId, 'CAPTCHA');
      try { chrome.tabs.remove(entry.tabId); } catch {}
      entry.phase = 'captcha';
      entry.tabId = null;
    }
  }
  await save();

  // Move to Round 2
  await round2_clickJs();
}

async function round2_clickJs() {
  state.batchPhase = 'clicking_js';
  await save();

  const activeTabs = state.batch.filter(t => t.tabId && t.phase === 'opened');

  for (let i = 0; i < activeTabs.length; i++) {
    if (state.shouldStop) return;
    const entry = activeTabs[i];

    try {
      // Bring tab to front so user sees the JS click
      await chrome.tabs.update(entry.tabId, { active: true });
      await sleep(400);
      await chrome.scripting.executeScript({
        target: { tabId: entry.tabId },
        files: ['content-amazon.js']
      });
      await chrome.tabs.sendMessage(entry.tabId, {
        action: 'startJsScan',
        timeout: state.jsTimeout
      });
      // Content script will find button, click it, and start waiting for data
      // It sends 'jsButtonClicked' then 'jsDataLoaded' or 'jsNoData'
    } catch (e) {
      entry.phase = 'data_timeout';
      tabErr(entry.tabId, `Inject: ${e.message}`);
    }

    // Small delay between clicks
    if (i < activeTabs.length - 1) await sleep(600);
  }

  // ── ROUND 3: Wait for data in all tabs ──
  state.batchPhase = 'waiting_data';
  await save();

  // Set a global timeout for data wait
  const dataTimeout = setTimeout(async () => {
    await load();
    if (state.batchPhase === 'waiting_data') {
      // Force-mark remaining tabs as timed out
      for (const t of state.batch) {
        if (t.tabId && !['data_ready', 'data_timeout', 'downloaded'].includes(t.phase)) {
          t.phase = 'data_timeout';
          tabErr(t.tabId, 'Data timeout');
        }
      }
      await save();
      await round4_download();
    }
  }, state.jsTimeout + 10000);

  // checkAllDataReady() will be called by message handlers as tabs report in
  // Store timeout handle to clear it
  state._dataTimeoutId = true; // flag only, actual handle managed locally
}

function checkAllDataReady() {
  const activeTabs = state.batch.filter(t => t.tabId && t.phase !== 'open_failed' && t.phase !== 'captcha');
  const allDone = activeTabs.every(t =>
    ['data_ready', 'data_timeout', 'downloaded', 'download_fail'].includes(t.phase)
  );

  if (allDone && state.batchPhase === 'waiting_data') {
    round4_download();
  }
}

async function round4_download() {
  state.batchPhase = 'downloading';
  await save();

  const readyTabs = state.batch.filter(t => t.tabId && t.phase === 'data_ready');

  for (let i = 0; i < readyTabs.length; i++) {
    if (state.shouldStop) return;
    const entry = readyTabs[i];

    try {
      // Bring tab to front
      await chrome.tabs.update(entry.tabId, { active: true });
      await sleep(400);

      // Clear download history so we have a clean slate
      await chrome.downloads.erase({});

      // Set the expected filename for this download
      const fileNum = state.downloadCounter;
      state.pendingRename = `${fileNum}-js`;
      state.downloadCounter++;
      await save();

      // Click download
      await chrome.tabs.sendMessage(entry.tabId, { action: 'clickDownload' });
      entry.phase = 'download_pending';
      await save();

      // Poll for the renamed file to appear completed
      const downloaded = await pollForRenamedDownload(`${fileNum}-js`, 8000);
      state.pendingRename = null; // clear rename flag

      if (downloaded) {
        entry.phase = 'downloaded';
        state.stats.downloaded++;
      } else {
        entry.phase = 'download_fail';
        tabErr(entry.tabId, 'Download not detected');
      }
      await save();
    } catch (e) {
      state.pendingRename = null;
      entry.phase = 'download_fail';
      tabErr(entry.tabId, `Download: ${e.message}`);
    }

    // Delay between downloads
    if (i < readyTabs.length - 1) await sleep(500);
  }

  // ── ROUND 5: Close all tabs ──
  await round5_close();
}

// Poll for a specific renamed file to complete
async function pollForRenamedDownload(expectedName, timeout) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    try {
      const items = await chrome.downloads.search({
        limit: 5,
        orderBy: ['-startTime']
      });
      for (const item of items) {
        const fn = (item.filename || '').toLowerCase();
        // Check if this is our renamed file
        if (fn.includes(expectedName.toLowerCase()) && item.state === 'complete' && item.fileSize > 0) {
          return true;
        }
        // File is ours but still downloading — wait
        if (fn.includes(expectedName.toLowerCase()) && item.state === 'in_progress') {
          await sleep(200);
          break;
        }
      }
      // Also accept any new CSV that completed (fallback if rename didn't work)
      for (const item of items) {
        const fn = (item.filename || '').toLowerCase();
        if ((fn.endsWith('.csv') || fn.includes('junglescout')) && item.state === 'complete' && item.fileSize > 0) {
          return true;
        }
      }
    } catch {}
    await sleep(200);
  }
  return false;
}

async function round5_close() {
  state.batchPhase = 'closing';
  closingBatch = true;
  await save();

  // Close all tabs that still have a tabId
  for (const entry of state.batch) {
    if (!entry.tabId) continue;
    try { await chrome.tabs.remove(entry.tabId); } catch {}
    entry.tabId = null;
    await sleep(200);
  }

  // Safety cleanup: close any leftover amazon.in tabs
  try {
    const allTabs = await chrome.tabs.query({ currentWindow: true });
    for (const tab of allTabs) {
      if (tab.id === state.scrappyTabId) continue;
      if (tab.url?.startsWith('chrome')) continue;
      if (tab.url?.includes('amazon.in')) {
        try { await chrome.tabs.remove(tab.id); } catch {}
        await sleep(100);
      }
    }
  } catch {}

  closingBatch = false;

  // ── Count stats for THIS batch (single source of truth) ──
  for (const entry of state.batch) {
    state.stats.processed++;
    // downloaded++ was already done in round4 — don't re-count
    // Only count skipped here for non-downloaded entries
    if (entry.phase !== 'downloaded') {
      state.stats.skipped++;
    }
  }

  state.batch = [];
  state.batchPhase = 'none';
  await save();

  // Switch back to Scrappy tab
  try { await chrome.tabs.update(state.scrappyTabId, { active: true }); } catch {}

  // Breather before next batch
  await sleep(500);

  // Check if we need more links from Scrappy
  if (state.nextLinkIndex >= state.links.length && !state.allLinksCollected) {
    safeSend(state.scrappyTabId, { action: 'scrollAndScan', batchSize: state.batchSize });
    // Will resume when linksFound arrives
  } else {
    startNextBatch();
  }
}

// ═══════════════════════════════════════════════════════════
// HELPERS
// ═══════════════════════════════════════════════════════════

async function waitAllTabsLoaded() {
  const maxWait = 30000;
  const start = Date.now();

  while (Date.now() - start < maxWait) {
    let allLoaded = true;
    for (const entry of state.batch) {
      if (!entry.tabId || entry.phase === 'open_failed') continue;
      try {
        const tab = await chrome.tabs.get(entry.tabId);
        if (tab.status !== 'complete') { allLoaded = false; break; }
      } catch {
        entry.phase = 'open_failed';
      }
    }
    if (allLoaded) return;
    await sleep(300);
  }
}

function markBatchTab(tabId, phase) {
  if (!tabId) return;
  const entry = state.batch.find(t => t.tabId === tabId);
  if (entry) {
    entry.phase = phase;
    save();
  }
}

function tabErr(tabId, msg) {
  state.errors.push(`[${tabId || '?'}] ${msg}`);
  save();
}

async function isCaptcha(tabId) {
  try {
    const r = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => {
        const txt = (document.title + ' ' + document.body.innerText).toLowerCase();
        return !!document.querySelector('form[action*="captcha"]') ||
               txt.includes('type the characters') ||
               txt.includes('are you a human') ||
               txt.includes('robot check');
      }
    });
    return r[0]?.result || false;
  } catch { return false; }
}

function safeSend(tabId, msg) {
  if (!tabId) return;
  try { chrome.tabs.sendMessage(tabId, msg).catch(() => {}); } catch {}
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}
