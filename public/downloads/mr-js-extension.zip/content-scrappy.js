// ═══════════════════════════════════════════════════════════
// Mr JS — Scrappy Content Script v3 (Keyboard Cursor)
// ═══════════════════════════════════════════════════════════
// Uses Scrappy's built-in keyboard navigation to traverse links.
// Virtual scrolling renders rows on demand — keyboard Down Arrow
// triggers new rows to render.

if (window._mrJsInjected) { /* already injected */ }
else { window._mrJsInjected = true; }

let cursorInitialized = false;

chrome.runtime.onMessage.addListener((msg, _sender, respond) => {
  switch (msg.action) {

    case 'scanLinks': {
      // Initialize cursor on first profile link, then collect first batch
      initCursorAndCollect(msg.batchSize || 5);
      respond({ ok: true });
      break;
    }

    case 'scrollAndScan': {
      // Collect next batch from current cursor position
      collectBatch(msg.batchSize || 5);
      respond({ ok: true });
      break;
    }

    case 'clickCopyForUrl': {
      clickCopyByUid(msg.uid);
      respond({ ok: true });
      break;
    }

    default:
      respond({ ok: false });
  }
  return true;
});

// ── Initialize cursor ────────────────────────────────────

function initCursorAndCollect(batchSize) {
  const firstLink = document.querySelector('a[href*="amazon.in/s?me="]');
  if (!firstLink) {
    chrome.runtime.sendMessage({ action: 'linksFound', links: [], noMore: true });
    return;
  }

  // NO clicking — clicks navigate to Amazon!
  // Instead: focus the table area and press Down Arrow to activate keyboard cursor
  const table = document.querySelector('table') || document.querySelector('[role="grid"]') || document.querySelector('tbody');
  if (table) table.focus();
  else document.body.focus();

  cursorInitialized = true;

  // Press Down Arrow to activate cursor on first row
  pressDown();

  setTimeout(() => {
    // Check if cursor activated (can we read a link?)
    const url = readCurrentLink();
    if (url) {
      // Cursor is active — collect the batch
      collectBatch(batchSize);
    } else {
      // Cursor didn't activate via Down — try focusing the first row directly
      const row = firstLink.closest('tr') || firstLink.closest('[role="row"]');
      if (row) row.focus();
      pressDown();
      setTimeout(() => collectBatch(batchSize), 400);
    }
  }, 500);
}

// ── Collect a batch of N links using keyboard ────────────

function collectBatch(batchSize) {
  const links = [];
  let collected = 0;
  let consecutiveSkips = 0;
  const maxSkips = 50; // safety limit — stop if 50 consecutive copied rows

  function readAndNext() {
    const url = readCurrentLink();
    const copied = isCurrentRowCopied();

    if (url && !copied) {
      links.push({ url, uid: url });
      collected++;
      consecutiveSkips = 0;
    } else if (copied) {
      // Skip this row — it's already copied
      consecutiveSkips++;
      if (consecutiveSkips >= maxSkips) {
        // Probably hit a block of all-copied rows — we're done
        sendLinks(links, true);
        return;
      }
    }

    if (collected >= batchSize) {
      pressDown();
      setTimeout(() => sendLinks(links, false), 300);
      return;
    }

    pressDown();

    setTimeout(() => {
      const nextUrl = readCurrentLink();

      if (!nextUrl || (links.length > 0 && !isCurrentRowCopied() && nextUrl === links[links.length - 1].url)) {
        sendLinks(links, links.length === 0);
        return;
      }

      readAndNext();
    }, 400);
  }

  readAndNext();
}

// ── Check if current row is already copied ───────────────

function isCurrentRowCopied() {
  // Find the row that has focus/cursor
  const active = document.activeElement;
  const row = active?.closest?.('tr') || active?.closest?.('[role="row"]');

  if (row) {
    // Check for "Copied" text in any button
    const buttons = row.querySelectorAll('button');
    for (const btn of buttons) {
      const txt = (btn.textContent || '').trim().toLowerCase();
      if (txt.includes('copied')) return true;
    }
    // Check for green/success styling on the first button
    const firstBtn = buttons[0];
    if (firstBtn) {
      const cls = (firstBtn.className || '').toLowerCase();
      if (cls.includes('success') || cls.includes('green') || cls.includes('copied')) return true;
    }
  }

  // Broader search: look for any visible row with a highlighted/selected state that has "Copied"
  const selectors = [
    'tr.selected', 'tr.highlighted', 'tr.active',
    'tr:focus-within', '[aria-selected="true"]'
  ];
  for (const sel of selectors) {
    const r = document.querySelector(sel);
    if (r) {
      const btns = r.querySelectorAll('button');
      for (const btn of btns) {
        if ((btn.textContent || '').toLowerCase().includes('copied')) return true;
      }
    }
  }

  return false;
}

function sendLinks(links, noMore) {
  chrome.runtime.sendMessage({
    action: 'linksFound',
    links,
    noMore
  });
}

// ── Read the currently highlighted link ──────────────────

function readCurrentLink() {
  // Strategy 1: The focused/active element IS a link
  const active = document.activeElement;
  if (active?.tagName === 'A' && active.href?.includes('amazon.in')) {
    return active.href;
  }

  // Strategy 2: Focused element is inside a row — find the link in that row
  if (active) {
    const row = active.closest('tr') || active.closest('[role="row"]');
    if (row) {
      const link = row.querySelector('a[href*="amazon.in/s?me="]');
      if (link?.href) return link.href;
    }
  }

  // Strategy 3: Look for selected/highlighted row
  const selectors = [
    'tr.selected a[href*="amazon.in"]',
    'tr.highlighted a[href*="amazon.in"]',
    'tr[data-selected] a[href*="amazon.in"]',
    'tr.active a[href*="amazon.in"]',
    '[class*="selected"] a[href*="amazon.in"]',
    '[class*="highlight"] a[href*="amazon.in"]',
    'tr:focus-within a[href*="amazon.in"]',
    '[aria-selected="true"] a[href*="amazon.in"]'
  ];
  for (const sel of selectors) {
    const el = document.querySelector(sel);
    if (el?.href) return el.href;
  }

  // Strategy 4: Check for row with outline/ring (Tailwind focus indicator)
  const rows = document.querySelectorAll('tr');
  for (const row of rows) {
    const style = window.getComputedStyle(row);
    if (row.classList.contains('ring-2') || row.classList.contains('ring-1') ||
        row.getAttribute('data-highlighted') === 'true' ||
        row.getAttribute('data-cursor') === 'true') {
      const link = row.querySelector('a[href*="amazon.in"]');
      if (link?.href) return link.href;
    }
  }

  // Strategy 5: Check for any link that has a special visual state
  const allLinks = document.querySelectorAll('a[href*="amazon.in/s?me="]');
  for (const link of allLinks) {
    if (link.matches(':focus, :focus-within, :focus-visible')) {
      return link.href;
    }
    // Check if parent row has focus
    const row = link.closest('tr');
    if (row?.matches(':focus, :focus-within')) return link.href;
  }

  return null;
}

// ── Keyboard dispatch ────────────────────────────────────

function pressDown() {
  const target = document.activeElement || document.body;
  target.dispatchEvent(new KeyboardEvent('keydown', {
    key: 'ArrowDown', code: 'ArrowDown',
    keyCode: 40, which: 40,
    bubbles: true, cancelable: true
  }));
  target.dispatchEvent(new KeyboardEvent('keyup', {
    key: 'ArrowDown', code: 'ArrowDown',
    keyCode: 40, which: 40,
    bubbles: true, cancelable: true
  }));
}

function pressCtrlC() {
  const target = document.activeElement || document.body;
  target.dispatchEvent(new KeyboardEvent('keydown', {
    key: 'c', code: 'KeyC', keyCode: 67,
    ctrlKey: true, bubbles: true, cancelable: true
  }));
  target.dispatchEvent(new KeyboardEvent('keyup', {
    key: 'c', code: 'KeyC', keyCode: 67,
    ctrlKey: true, bubbles: true, cancelable: true
  }));
}

// ── Click copy button by URL match ───────────────────────

function clickCopyByUid(uid) {
  if (!uid) return;

  // Find the <a> with matching URL in the DOM
  const allLinks = document.querySelectorAll('a[href*="amazon.in/s?me="]');
  for (const a of allLinks) {
    if (a.href !== uid) continue;

    const row = a.closest('tr') || a.closest('[role="row"]');
    if (!row) continue;

    // First button in ACTION column = copy button
    const buttons = row.querySelectorAll('button');
    if (buttons.length >= 1) {
      buttons[0].click();
      return;
    }
  }

  // Fallback: if row not in DOM (scrolled away), use keyboard
  // Click the link to move cursor there, then Ctrl+C
  // This won't work if the row is virtualized out — just skip
}
