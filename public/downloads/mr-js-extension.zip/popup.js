const $ = id => document.getElementById(id);
let pollTimer;

document.addEventListener('DOMContentLoaded', () => {
  refresh();
  pollTimer = setInterval(refresh, 800);
});

async function refresh() {
  try {
    const r = await chrome.runtime.sendMessage({ action: 'getState' });
    if (r?.state) render(r.state);
  } catch {}
}

function render(s) {
  const isActive  = s.status === 'running';
  const isDone    = s.status === 'done';
  const isIdle    = s.status === 'idle';
  const isFinished = ['done', 'stopped', 'error'].includes(s.status);

  // Dot
  $('dot').className = 'dot';
  if (isActive) $('dot').classList.add('active');
  if (isDone) $('dot').classList.add('done');
  if (s.status === 'error' || s.status === 'stopped') $('dot').classList.add('err');

  // Status
  const batchPhases = {
    opening: '📂 Opening tabs…', waiting_load: '⏳ Pages loading…',
    clicking_js: '🔍 Clicking JS scan…', waiting_data: '📊 Waiting for data…',
    downloading: '💾 Downloading CSVs…', closing: '🧹 Closing tabs…'
  };
  const bp = batchPhases[s.batchPhase] || '';
  const bc = (s.batch || []).length;
  const msgs = {
    idle:    'Idle — open Scrappy Add Seller page',
    running: `${bp} <b>${s.stats.processed}</b>/<b>${s.stats.total}</b> done`,
    done:    `Done! <b>${s.stats.downloaded}</b> CSVs, <b>${s.stats.skipped}</b> skipped`,
    stopped: `Stopped at ${s.stats.processed}`,
    error:   'Error — check below'
  };
  $('stxt').innerHTML = msgs[s.status] || s.status;

  // Progress
  $('prog').classList.toggle('hidden', isIdle);
  const total = s.stats.total || 1;
  const pct = Math.min(100, (s.stats.processed / total) * 100);
  $('pfill').style.width = `${pct}%`;
  $('sProc').textContent = s.stats.processed;
  $('sTotal').textContent = s.stats.total;
  $('sDl').textContent = s.stats.downloaded;
  $('sSkip').textContent = s.stats.skipped;

  // Active tabs info
  $('activeInfo').classList.toggle('hidden', !isActive);
  $('sActive').textContent = bc;
  $('sMax').textContent = s.batchSize;

  // Config
  $('cfgSection').classList.toggle('hidden', !isIdle);
  $('infoBox').classList.toggle('hidden', !isIdle);

  // Buttons
  let html = '';
  if (isIdle) {
    html = `<button class="btn-start" id="btnStart">🚀 Start Mr JS</button>`;
  } else if (isActive) {
    html = `<button class="btn-stop" id="btnStop">⏹ Stop</button>`;
  } else if (isFinished) {
    html = `<button class="btn-new" id="btnNew">🔄 New Run</button>
            <button class="btn-reset" id="btnReset">Clear</button>`;
  }
  $('btns').innerHTML = html;

  $('btnStart')?.addEventListener('click', handleStart);
  $('btnStop')?.addEventListener('click', () => chrome.runtime.sendMessage({ action: 'stop' }));
  $('btnNew')?.addEventListener('click', () => chrome.runtime.sendMessage({ action: 'reset' }));
  $('btnReset')?.addEventListener('click', () => chrome.runtime.sendMessage({ action: 'reset' }));

  // Errors
  if (s.errors?.length > 0) {
    $('errsSection').classList.remove('hidden');
    $('errSum').textContent = `${s.errors.length} event(s)`;
    $('errTxt').textContent = s.errors.slice(-30).join('\n');
  } else {
    $('errsSection').classList.add('hidden');
  }
}

async function handleStart() {
  $('validMsg').classList.remove('show');

  let tabs;
  try { tabs = await chrome.tabs.query({ active: true, currentWindow: true }); }
  catch { return showValid('Cannot access tabs'); }

  const tab = tabs[0];
  if (!tab?.url) return showValid('Cannot read tab URL');

  const url = tab.url;
  if (!url.includes('/manage-sellers') && !url.includes('add-seller')) {
    return showValid('Navigate to Scrappy Add Seller page first');
  }

  const maxParallel = parseInt($('cfgParallel')?.value || '5', 10);
  const delay = parseInt($('cfgDelay')?.value || '800', 10);
  const timeout = parseInt($('cfgTimeout')?.value || '30', 10) * 1000;

  if (maxParallel < 1 || maxParallel > 10) return showValid('Parallel tabs: 1-10');
  if (delay < 500) return showValid('Delay must be at least 500ms');

  await chrome.runtime.sendMessage({
    action: 'start',
    scrappyTabId: tab.id,
    maxParallel,
    delay,
    jsTimeout: timeout
  });
}

function showValid(msg) {
  $('validMsg').textContent = msg;
  $('validMsg').classList.add('show');
}
