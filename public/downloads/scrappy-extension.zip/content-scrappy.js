// ============================================================
// Scrappy Content Script v2
// Runs on: http://100.82.234.106:3000/*
// ============================================================

let overlay = null;
let statusEl = null;
let logContainer = null;
let alertOverlay = null;
let skipSet = [];
let lastClickedAsin = '';

// Notify background that page is ready (handles reload recovery)
chrome.runtime.sendMessage({ action: 'SCRAPPY_PAGE_READY' }).catch(() => {});

// ---- Message Handler ----
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.action) {

    case 'CLICK_AMZ_LINK':
      if (msg.skipSet) skipSet = msg.skipSet;
      clickAmzLink(msg.lastProcessedAsin);
      sendResponse({ ok: true });
      break;

    case 'CLICK_APPROVE':
      clickActionButton('approve', msg.asin, msg.reason);
      sendResponse({ ok: true });
      break;

    case 'CLICK_NOT_APPROVED':
      clickActionButton('not_approved', msg.asin, msg.reason);
      sendResponse({ ok: true });
      break;

    case 'CLICK_NEXT_PAGE':
      clickNextPage();
      sendResponse({ ok: true });
      break;

    case 'RELOAD_PAGE':
      addLog('Reloading page for next batch...');
      location.reload();
      sendResponse({ ok: true });
      break;

    case 'SET_SKIP_LIST':
      if (msg.skipSet) skipSet = msg.skipSet;
      sendResponse({ ok: true });
      break;

    case 'SHOW_OVERLAY':
      showOverlay();
      sendResponse({ ok: true });
      break;

    case 'HIDE_OVERLAY':
      hideOverlay();
      sendResponse({ ok: true });
      break;

    case 'SHOW_ALERT':
      showAlert(msg.title, msg.message, msg.type, msg.big);
      sendResponse({ ok: true });
      break;

    case 'STATE_UPDATE':
      if (msg.state) updateStats(msg.state);
      sendResponse({ ok: true });
      break;

    case 'LOG':
      addLog(msg.message);
      sendResponse({ ok: true });
      break;
  }
  return true;
});

// ---- DOM Helpers ----

function getTableRows() {
  const rows = document.querySelectorAll('table tbody tr');
  return Array.from(rows);
}

function getAsinFromRow(row) {
  // ASIN is in the 2nd column (index 1)
  const cells = row.querySelectorAll('td');
  if (cells.length >= 2) {
    return cells[1].textContent.trim();
  }
  return '';
}

function getAmzViewLink(row) {
  // Find all elements that say "View Link" in the row
  const allLinks = row.querySelectorAll('a, button');
  const viewLinks = Array.from(allLinks).filter(el =>
    el.textContent.trim().toLowerCase() === 'view link'
  );

  // AMZ LINK is the second "View Link" (first is Product Link)
  if (viewLinks.length >= 2) return viewLinks[1];
  if (viewLinks.length === 1) return viewLinks[0];

  // Fallback: find by column header index
  return findByColumnHeader(row, 'AMZ LINK');
}

function findByColumnHeader(row, headerText) {
  const headers = document.querySelectorAll('table thead th, table thead td');
  let colIndex = -1;
  headers.forEach((th, i) => {
    if (th.textContent.trim().toUpperCase().includes(headerText)) {
      colIndex = i;
    }
  });

  if (colIndex >= 0) {
    const cells = row.querySelectorAll('td');
    if (cells[colIndex]) {
      const link = cells[colIndex].querySelector('a, button');
      return link;
    }
  }
  return null;
}

// ---- Click AMZ Link ----

function clickAmzLink(lastProcessedAsin) {
  const rows = getTableRows();

  if (rows.length === 0) {
    chrome.runtime.sendMessage({ action: 'NO_MORE_ROWS' });
    return;
  }

  // Find the first non-skipped row
  let targetRow = null;
  let targetAsin = '';

  for (let i = 0; i < rows.length; i++) {
    const asin = getAsinFromRow(rows[i]);
    if (!skipSet.includes(asin)) {
      targetRow = rows[i];
      targetAsin = asin;
      break;
    }
  }

  if (!targetRow) {
    // All visible rows are in skip set — try next page
    addLog('All visible rows are stuck/skipped. Moving to next page.');
    chrome.runtime.sendMessage({ action: 'NO_MORE_ROWS' });
    return;
  }

  // Check if this is the same ASIN we just processed (stuck row detection)
  if (targetAsin === lastClickedAsin && lastClickedAsin !== '') {
    // This ASIN didn't move after our action — it's stuck
    addLog(`Row stuck: ${targetAsin} still in first position. Skipping.`);
    skipSet.push(targetAsin);
    chrome.runtime.sendMessage({ action: 'ROW_SKIPPED', asin: targetAsin });
    return;
  }

  lastClickedAsin = targetAsin;
  updateStatus(`Processing: ${targetAsin}`);
  highlightRow(targetRow);

  const amzViewLink = getAmzViewLink(targetRow);

  if (amzViewLink) {
    addLog(`Opening AMZ link for: ${targetAsin}`);
    amzViewLink.click();
  } else {
    addLog(`ERROR: No AMZ View Link found for ${targetAsin}. Skipping.`);
    skipSet.push(targetAsin);
    chrome.runtime.sendMessage({ action: 'ROW_SKIPPED', asin: targetAsin });
  }
}

// ---- Click Action Button ----

function clickActionButton(type, asin, reason) {
  const rows = getTableRows();
  if (rows.length === 0) {
    chrome.runtime.sendMessage({ action: 'NO_MORE_ROWS' });
    return;
  }

  // Find the row with matching ASIN, or use first non-skipped row
  let targetRow = null;
  for (const row of rows) {
    const rowAsin = getAsinFromRow(row);
    if (asin && rowAsin === asin) {
      targetRow = row;
      break;
    }
  }

  // Fallback: first non-skipped row
  if (!targetRow) {
    for (const row of rows) {
      const rowAsin = getAsinFromRow(row);
      if (!skipSet.includes(rowAsin)) {
        targetRow = row;
        break;
      }
    }
  }

  if (!targetRow) {
    chrome.runtime.sendMessage({ action: 'NO_MORE_ROWS' });
    return;
  }

  const rowAsin = getAsinFromRow(targetRow);
  const buttons = targetRow.querySelectorAll('button, a');
  let targetBtn = null;

  for (const btn of buttons) {
    const text = btn.textContent.trim().toLowerCase();
    if (type === 'approve' && text === 'approve') {
      targetBtn = btn;
      break;
    }
    if (type === 'not_approved' && (text === 'not appr.' || text === 'not approved' || text.includes('not app'))) {
      targetBtn = btn;
      break;
    }
  }

  if (targetBtn) {
    addLog(`Clicking "${type === 'approve' ? 'Approve' : 'Not Appr.'}" for ${rowAsin}`);
    targetBtn.click();

    // Wait for row removal, then confirm
    setTimeout(() => {
      // Check if row was actually removed
      const newRows = getTableRows();
      const stillThere = newRows.some(r => getAsinFromRow(r) === rowAsin && !skipSet.includes(rowAsin));

      chrome.runtime.sendMessage({
        action: 'ROW_ACTION_DONE',
        wasApproved: type === 'approve',
        asin: rowAsin,
        reason: reason || ''
      });
    }, 1500);
  } else {
    addLog(`ERROR: Could not find ${type} button for ${rowAsin}`);
    skipSet.push(rowAsin);
    chrome.runtime.sendMessage({ action: 'ROW_SKIPPED', asin: rowAsin });
  }
}

// ---- Next Page ----

function clickNextPage() {
  const allElements = document.querySelectorAll('button, a, span');
  let nextBtn = null;

  for (const el of allElements) {
    const text = el.textContent.trim().toLowerCase();
    // Match "Next >" or just "Next"
    if (text === 'next' || text === 'next >' || text === 'next ›') {
      nextBtn = el;
      break;
    }
  }

  // Also try matching by aria-label or class
  if (!nextBtn) {
    nextBtn = document.querySelector('[aria-label*="next" i], [class*="next" i]');
  }

  if (nextBtn && !nextBtn.disabled && !nextBtn.classList.contains('disabled')) {
    addLog('Navigating to next page...');
    nextBtn.click();
    skipSet = [];
    lastClickedAsin = '';
    setTimeout(() => {
      chrome.runtime.sendMessage({ action: 'NEXT_PAGE_CLICKED' });
    }, 2500);
  } else {
    addLog('No more pages available.');
    chrome.runtime.sendMessage({ action: 'NO_NEXT_PAGE' });
  }
}

// ---- Overlay UI ----

function showOverlay() {
  if (overlay) overlay.remove();

  overlay = document.createElement('div');
  overlay.id = 'scrappy-auto-overlay';
  overlay.innerHTML = `
    <div class="sac-header">
      <div class="sac-dot" id="sac-dot"></div>
      <span class="sac-title">ASIN Auto Checker v2</span>
      <button class="sac-minimize" id="sac-minimize">—</button>
    </div>
    <div class="sac-body" id="sac-body">
      <div class="sac-status" id="sac-status">Starting...</div>
      <div class="sac-stats">
        <div class="sac-stat">
          <span class="sac-stat-num" id="sac-total">0</span>
          <span class="sac-stat-label">Processed</span>
        </div>
        <div class="sac-stat sac-stat-ok">
          <span class="sac-stat-num" id="sac-approved">0</span>
          <span class="sac-stat-label">Approved</span>
        </div>
        <div class="sac-stat sac-stat-no">
          <span class="sac-stat-num" id="sac-not-approved">0</span>
          <span class="sac-stat-label">Not Appr.</span>
        </div>
        <div class="sac-stat sac-stat-skip">
          <span class="sac-stat-num" id="sac-skipped">0</span>
          <span class="sac-stat-label">Skipped</span>
        </div>
      </div>
      <div class="sac-logs" id="sac-logs"></div>
    </div>
  `;

  document.body.appendChild(overlay);
  statusEl = document.getElementById('sac-status');
  logContainer = document.getElementById('sac-logs');

  // Make draggable
  makeDraggable(overlay, overlay.querySelector('.sac-header'));

  document.getElementById('sac-minimize').addEventListener('click', () => {
    const body = document.getElementById('sac-body');
    body.style.display = body.style.display === 'none' ? 'block' : 'none';
  });
}

function hideOverlay() {
  if (overlay) {
    overlay.remove();
    overlay = null;
    statusEl = null;
    logContainer = null;
  }
  dismissAlert();
}

function updateStatus(text) {
  if (statusEl) statusEl.textContent = text;
}

function updateStats(s) {
  const el = (id) => document.getElementById(id);
  const total = el('sac-total');
  const app = el('sac-approved');
  const notApp = el('sac-not-approved');
  const skip = el('sac-skipped');
  const dot = el('sac-dot');

  if (total) total.textContent = s.processedCount || 0;
  if (app) app.textContent = s.approvedCount || 0;
  if (notApp) notApp.textContent = s.notApprovedCount || 0;
  if (skip) skip.textContent = s.skippedCount || 0;

  if (dot) {
    dot.className = 'sac-dot';
    if (s.running && !s.paused) dot.classList.add('sac-active');
    else if (s.paused) dot.classList.add('sac-paused');
  }

  if (s.currentAsin) updateStatus(`Processing: ${s.currentAsin}`);
  if (s.waitingForUser) updateStatus(`⚠ ${s.waitReason}`);
}

function addLog(message) {
  if (!logContainer) return;
  const line = document.createElement('div');
  line.className = 'sac-log-line';

  if (message.includes('ERROR') || message.includes('ALERT') || message.includes('TIMEOUT')) {
    line.classList.add('sac-log-error');
  } else if (message.includes('Approve') || message.includes('approved')) {
    line.classList.add('sac-log-ok');
  } else if (message.includes('Not') || message.includes('Skip') || message.includes('stuck')) {
    line.classList.add('sac-log-warn');
  }

  line.textContent = message;
  logContainer.appendChild(line);
  logContainer.scrollTop = logContainer.scrollHeight;

  while (logContainer.children.length > 80) {
    logContainer.removeChild(logContainer.firstChild);
  }
}

function highlightRow(row) {
  document.querySelectorAll('.sac-highlight-row').forEach(el =>
    el.classList.remove('sac-highlight-row')
  );
  row.classList.add('sac-highlight-row');
}

// ---- Alert Overlay ----

function showAlert(title, message, type, big) {
  dismissAlert();

  alertOverlay = document.createElement('div');
  alertOverlay.id = 'sac-alert-overlay';
  alertOverlay.className = big ? 'sac-alert-big' : '';

  const bgColor = type === 'error' ? '#dc2626' : type === 'warning' ? '#d97706' : '#16a34a';

  alertOverlay.innerHTML = `
    <div class="sac-alert-box" style="border-color: ${bgColor}">
      <div class="sac-alert-header" style="background: ${bgColor}">
        ${type === 'error' ? '⚠' : type === 'warning' ? '⚡' : '✓'} ${title}
      </div>
      <div class="sac-alert-body">
        <p>${message}</p>
        <button class="sac-alert-dismiss" id="sac-alert-dismiss">Dismiss</button>
      </div>
    </div>
  `;

  document.body.appendChild(alertOverlay);

  document.getElementById('sac-alert-dismiss').addEventListener('click', dismissAlert);
}

function dismissAlert() {
  if (alertOverlay) {
    alertOverlay.remove();
    alertOverlay = null;
  }
}

// ---- Drag Helper ----

function makeDraggable(element, handle) {
  let isDragging = false;
  let startX, startY, origX, origY;

  handle.addEventListener('mousedown', (e) => {
    if (e.target.tagName === 'BUTTON') return;
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    const rect = element.getBoundingClientRect();
    origX = rect.left;
    origY = rect.top;
    e.preventDefault();
  });

  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;
    element.style.left = (origX + dx) + 'px';
    element.style.top = (origY + dy) + 'px';
    element.style.right = 'auto';
    element.style.bottom = 'auto';
  });

  document.addEventListener('mouseup', () => {
    isDragging = false;
  });
}
