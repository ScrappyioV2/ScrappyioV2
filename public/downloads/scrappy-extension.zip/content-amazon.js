// ============================================================
// Amazon Seller Central Content Script v2
// Runs on: https://sellercentral.amazon.in/*
// ============================================================

let hasChecked = false;

// Listen for explicit check command
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'CHECK_APPROVAL') {
    if (!hasChecked) checkPage();
    sendResponse({ ok: true });
  }
  return true;
});

// Auto-check when page loads
if (document.readyState === 'complete') {
  setTimeout(() => { if (!hasChecked) checkPage(); }, 1500);
} else {
  window.addEventListener('load', () => {
    setTimeout(() => { if (!hasChecked) checkPage(); }, 2000);
  });
}

function checkPage() {
  waitForContent(() => {
    hasChecked = true;

    const url = window.location.href;
    const bodyText = document.body.innerText;
    const bodyLower = bodyText.toLowerCase();

    // Extract ASIN from URL
    let asin = '';
    const asinMatch = url.match(/asin=([A-Z0-9]+)/i);
    if (asinMatch) asin = asinMatch[1];

    // ---- 1. Check for Login/Session Expired ----
    if (isLoginPage(url, bodyLower)) {
      showBadge('🔒 LOGIN REQUIRED', '#dc2626');
      chrome.runtime.sendMessage({ action: 'AMAZON_LOGIN_REQUIRED', asin });
      return;
    }

    // ---- 2. Check for CAPTCHA ----
    if (isCaptchaPage(bodyLower)) {
      showBadge('🤖 CAPTCHA DETECTED', '#d97706');
      chrome.runtime.sendMessage({ action: 'AMAZON_CAPTCHA_DETECTED', asin });
      return;
    }

    // ---- 3. Check for Error / 404 Pages ----
    if (isErrorPage(bodyLower)) {
      showBadge('⚠ ERROR PAGE', '#ef4444');
      chrome.runtime.sendMessage({
        action: 'AMAZON_PAGE_RESULT',
        result: 'error',
        asin,
        reason: 'Error/404 page on Amazon'
      });
      return;
    }

    // ---- 4. Check Approval Status ----
    let result = 'unknown';
    let reason = '';

    // APPROVED indicators
    const hasSellYours = bodyLower.includes('sell yours');
    const canSell = bodyLower.includes('you can sell this product');

    // NOT APPROVED indicators
    const hasRequestApproval = bodyLower.includes('request approval');
    const needsApproval = bodyLower.includes('you need approval to sell');
    const notAccepting = bodyLower.includes('not accepting applications');

    if (hasSellYours && canSell) {
      result = 'approved';
      reason = 'Sell yours button found + "You can sell this product"';
    } else if (hasSellYours) {
      result = 'approved';
      reason = 'Sell yours button found';
    } else if (canSell) {
      result = 'approved';
      reason = '"You can sell this product" text found';
    } else if (hasRequestApproval && needsApproval) {
      result = 'not_approved';
      reason = 'Request approval button + "You need approval to sell"';
    } else if (hasRequestApproval) {
      result = 'not_approved';
      reason = 'Request approval button found';
    } else if (needsApproval) {
      result = 'not_approved';
      reason = '"You need approval to sell" text found';
    } else if (notAccepting) {
      result = 'not_approved';
      reason = '"Not accepting applications" text found';
    } else {
      result = 'unknown';
      // Capture first 200 chars of page content for debugging
      const snippet = bodyText.substring(0, 200).replace(/\n/g, ' ').trim();
      reason = `Unexpected page content: "${snippet}"`;
    }

    // ---- Also capture condition details ----
    // Look for specific condition text for the CSV
    const conditionLines = [];
    if (bodyLower.includes('new')) conditionLines.push('New');
    if (bodyLower.includes('used')) conditionLines.push('Used');
    if (bodyLower.includes('refurbished')) conditionLines.push('Refurbished');
    if (bodyLower.includes('collectible')) conditionLines.push('Collectible');

    // Check if there are specific category restrictions mentioned
    const categoryMatch = bodyText.match(/(?:category|branded).*?condition\(s\)/gi);
    if (categoryMatch) {
      reason += ` | Conditions: ${categoryMatch.join('; ')}`;
    }

    // Show visual badge
    if (result === 'approved') {
      showBadge('✓ APPROVED', '#22c55e');
    } else if (result === 'not_approved') {
      showBadge('✗ NOT APPROVED', '#ef4444');
    } else {
      showBadge('? UNKNOWN → Not Appr.', '#f59e0b');
    }

    console.log(`[ASIN Checker] ${asin}: ${result} — ${reason}`);

    // Send result to background
    chrome.runtime.sendMessage({
      action: 'AMAZON_PAGE_RESULT',
      result,
      asin,
      reason
    });
  });
}

// ---- Detection Functions ----

function isLoginPage(url, bodyLower) {
  const loginUrlPatterns = ['/signin', '/ap/signin', 'identity-sso', '/ap/oa', 'auth/'];
  const loginTextPatterns = ['sign in', 'sign-in', 'email or mobile phone number', 'password', 'forgot your password'];

  if (loginUrlPatterns.some(p => url.toLowerCase().includes(p))) return true;

  let loginTextCount = 0;
  for (const p of loginTextPatterns) {
    if (bodyLower.includes(p)) loginTextCount++;
  }
  // If 2+ login indicators found in body text, it's a login page
  return loginTextCount >= 2;
}

function isCaptchaPage(bodyLower) {
  const captchaIndicators = [
    'enter the characters',
    'type the characters',
    'captcha',
    'robot',
    'automated access',
    'unusual traffic',
    'verify you are a human',
    'security check'
  ];
  return captchaIndicators.some(t => bodyLower.includes(t));
}

function isErrorPage(bodyLower) {
  const errorIndicators = [
    'page not found',
    'something went wrong',
    'sorry, we couldn',
    'service unavailable',
    '404',
    'internal server error',
    'this page isn\'t working',
    'err_connection'
  ];
  // Must match at least one AND not be a normal selling application page
  const isSellingApp = bodyLower.includes('selling application');
  if (isSellingApp) return false;

  return errorIndicators.some(t => bodyLower.includes(t));
}

// ---- Wait for Content ----

function waitForContent(callback, maxWait = 15000) {
  const start = Date.now();

  function check() {
    const bodyText = (document.body.innerText || '').toLowerCase();
    const hasContent =
      bodyText.includes('sell yours') ||
      bodyText.includes('request approval') ||
      bodyText.includes('selling application') ||
      bodyText.includes('you can sell') ||
      bodyText.includes('you need approval') ||
      bodyText.includes('not accepting') ||
      bodyText.includes('sign in') ||
      bodyText.includes('captcha') ||
      bodyText.includes('enter the characters') ||
      bodyText.includes('page not found') ||
      bodyText.includes('something went wrong');

    if (hasContent || (Date.now() - start > maxWait)) {
      callback();
    } else {
      setTimeout(check, 500);
    }
  }

  check();
}

// ---- Visual Badge ----

function showBadge(text, color) {
  // Remove existing badge if any
  const existing = document.getElementById('sac-amazon-badge');
  if (existing) existing.remove();

  const badge = document.createElement('div');
  badge.id = 'sac-amazon-badge';
  badge.style.cssText = `
    position: fixed;
    top: 12px;
    right: 12px;
    background: ${color};
    color: white;
    padding: 14px 28px;
    border-radius: 10px;
    font-size: 18px;
    font-weight: bold;
    z-index: 999999;
    box-shadow: 0 4px 24px rgba(0,0,0,0.4);
    font-family: 'Segoe UI', system-ui, sans-serif;
    letter-spacing: 0.5px;
  `;
  badge.textContent = text;
  document.body.appendChild(badge);
}
