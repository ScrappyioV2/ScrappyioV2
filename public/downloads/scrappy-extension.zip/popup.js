// ============================================================
// Popup Controller v2
// ============================================================

const $ = id => document.getElementById(id);

const btnStart = $('btnStart');
const btnStop = $('btnStop');
const btnStop2 = $('btnStop2');
const btnPause = $('btnPause');
const btnResume = $('btnResume');
const btnExport = $('btnExport');
const btnClear = $('btnClear');
const statusDot = $('statusDot');
const statusText = $('statusText');
const statTotal = $('statTotal');
const statApproved = $('statApproved');
const statNotAppr = $('statNotAppr');
const statSkipped = $('statSkipped');
const delayMin = $('delayMin');
const delayMax = $('delayMax');
const batchLimit = $('batchLimit');
const autoNextToggle = $('autoNextToggle');
const logBox = $('logBox');
const mainControls = $('mainControls');
const resumeControls = $('resumeControls');

// ---- Init: get current state ----
chrome.runtime.sendMessage({ action: 'GET_STATE' }, (state) => {
  if (state) updateUI(state);
});

// ---- Button Handlers ----

btnStart.addEventListener('click', () => {
  sendSettings();
  chrome.runtime.sendMessage({ action: 'START' });
});

btnStop.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'STOP' });
});

btnStop2.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'STOP' });
});

btnPause.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'PAUSE' }, (resp) => {
    // UI will update via STATE_UPDATE
  });
});

btnResume.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'RESUME_AFTER_WAIT' });
});

// ---- Settings ----

function sendSettings() {
  chrome.runtime.sendMessage({
    action: 'SET_SETTINGS',
    delayMin: parseInt(delayMin.value) || 2,
    delayMax: parseInt(delayMax.value) || 12,
    batchLimit: parseInt(batchLimit.value) || 0,
    autoNextPage: autoNextToggle.checked
  });
}

delayMin.addEventListener('change', sendSettings);
delayMax.addEventListener('change', sendSettings);
batchLimit.addEventListener('change', sendSettings);
autoNextToggle.addEventListener('change', sendSettings);

// ---- CSV Export ----

btnExport.addEventListener('click', () => {
  chrome.runtime.sendMessage({ action: 'GET_CSV_LOG' }, (resp) => {
    if (!resp || !resp.csvLog || resp.csvLog.length === 0) {
      addLogEntry('[Export] No log entries to export.');
      return;
    }

    const rows = resp.csvLog;
    let csv = 'ASIN,Status,Reason,Timestamp\n';
    for (const r of rows) {
      // Escape fields that may contain commas or quotes
      const reason = `"${(r.reason || '').replace(/"/g, '""')}"`;
      csv += `${r.asin},${r.status},${reason},${r.timestamp}\n`;
    }

    // Download
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    const ts = new Date().toISOString().slice(0, 10);
    a.download = `asin-checker-log-${ts}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    addLogEntry(`[Export] Downloaded ${rows.length} entries.`);
  });
});

btnClear.addEventListener('click', () => {
  if (confirm('Clear all stats and log? This cannot be undone.')) {
    chrome.runtime.sendMessage({ action: 'CLEAR_LOG' });
    logBox.innerHTML = '';
    addLogEntry('[Clear] Stats and log cleared.');
  }
});

// ---- Listen for Updates ----

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === 'STATE_UPDATE') updateUI(msg.state);
  if (msg.action === 'LOG') addLogEntry(msg.message);
});

// ---- UI Update ----

function updateUI(s) {
  statTotal.textContent = s.processedCount || 0;
  statApproved.textContent = s.approvedCount || 0;
  statNotAppr.textContent = s.notApprovedCount || 0;
  statSkipped.textContent = s.skippedCount || 0;

  delayMin.value = s.delayMin || 2;
  delayMax.value = s.delayMax || 12;
  batchLimit.value = s.batchLimit || 0;
  autoNextToggle.checked = s.autoNextPage !== false;

  if (s.waitingForUser) {
    // Show resume controls
    mainControls.style.display = 'none';
    resumeControls.style.display = 'flex';
    statusDot.className = 'status-dot waiting';
    statusText.textContent = `⚠ ${s.waitReason}`;
  } else if (s.running) {
    mainControls.style.display = 'flex';
    resumeControls.style.display = 'none';
    btnStart.disabled = true;
    btnStop.disabled = false;
    btnPause.disabled = false;

    if (s.paused) {
      statusDot.className = 'status-dot paused';
      statusText.textContent = 'Paused';
      btnPause.textContent = '▶';
    } else {
      statusDot.className = 'status-dot active';
      statusText.textContent = s.currentAsin ? `Processing: ${s.currentAsin}` : 'Running...';
      btnPause.textContent = '⏸';
    }
  } else {
    mainControls.style.display = 'flex';
    resumeControls.style.display = 'none';
    btnStart.disabled = false;
    btnStop.disabled = true;
    btnPause.disabled = true;
    btnPause.textContent = '⏸';
    statusDot.className = 'status-dot';

    if (s.processedCount > 0) {
      statusText.textContent = `Done — ${s.processedCount} processed`;
    } else {
      statusText.textContent = 'Idle — ready to start';
    }
  }
}

// ---- Log ----

function addLogEntry(message) {
  const entry = document.createElement('div');
  entry.className = 'log-entry';
  if (message.includes('ERROR') || message.includes('ALERT') || message.includes('TIMEOUT')) {
    entry.classList.add('error');
  } else if (message.includes('Approve') || message.includes('approved')) {
    entry.classList.add('success');
  } else if (message.includes('Not') || message.includes('Skip') || message.includes('WARNING')) {
    entry.classList.add('warn');
  }
  entry.textContent = message;
  logBox.appendChild(entry);
  logBox.scrollTop = logBox.scrollHeight;

  while (logBox.children.length > 100) {
    logBox.removeChild(logBox.firstChild);
  }
}
