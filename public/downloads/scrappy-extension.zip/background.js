// ============================================================
// Scrappy ASIN Auto Checker v2 — Background Service Worker
// ============================================================

// ---------- Default State ----------
const DEFAULT_STATE = {
  running: false,
  paused: false,
  waitingForUser: false,
  waitReason: '',
  scrappyTabId: null,
  amazonTabId: null,
  processedCount: 0,
  approvedCount: 0,
  notApprovedCount: 0,
  skippedCount: 0,
  currentAsin: '',
  lastProcessedAsin: '',
  consecutiveSkips: 0,
  skipSet: [],
  emptyReloads: 0,
  delayMin: 2,
  delayMax: 12,
  autoNextPage: true,
  batchLimit: 0,
  existingAmazonTabIds: [],
  amazonTabOpenTime: 0,
  sinceLastRefresh: 0,
  refreshInterval: 50,
  generation: 0,           // increments on every STOP — all pending callbacks check this
  pendingRefresh: false,    // true while waiting for Scrappy to reload after 50-ASIN refresh
  csvLog: []
};

let state = { ...DEFAULT_STATE };
let amazonTimeoutTimer = null;

// ---------- Init: restore state from storage ----------
chrome.storage.local.get('sacState', (data) => {
  if (data.sacState) {
    state = { ...DEFAULT_STATE, ...data.sacState };
    // Reset transient fields
    state.amazonTabId = null;
    state.amazonTabOpenTime = 0;

    // If a refresh was in progress, keep running — SCRAPPY_PAGE_READY will resume
    if (state.running && state.pendingRefresh) {
      log('Service worker restarted during refresh. Waiting for Scrappy page to load...');
      saveState();
      return;
    }

    // If it was running but NOT refreshing, it was a real crash — stop cleanly
    if (state.running && !state.pendingRefresh) {
      log('Service worker restarted unexpectedly. Press Start to resume.');
      state.running = false;
      state.paused = false;
      saveState();
    }
  }
});

function saveState() {
  const toSave = { ...state };
  chrome.storage.local.set({ sacState: toSave });
}

// Helper: check if a callback's generation matches current — if not, stop was called
function isStale(gen) {
  return gen !== state.generation;
}

// ---------- Message Router ----------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.action) {

    case 'START':
      startAutomation();
      sendResponse({ ok: true });
      break;

    case 'STOP':
      stopAutomation('User stopped');
      sendResponse({ ok: true });
      break;

    case 'PAUSE':
      state.paused = !state.paused;
      if (state.paused) log('Paused by user.');
      else {
        log('Resumed.');
        processNextRow();
      }
      broadcastState();
      saveState();
      sendResponse({ ok: true, paused: state.paused });
      break;

    case 'RESUME_AFTER_WAIT':
      state.waitingForUser = false;
      state.waitReason = '';
      state.paused = false;
      log('User resolved issue. Resuming...');
      if (state.amazonTabId) {
        chrome.tabs.remove(state.amazonTabId).catch(() => {});
        state.amazonTabId = null;
      }
      broadcastState();
      saveState();
      setTimeout(() => processNextRow(), 2000);
      sendResponse({ ok: true });
      break;

    case 'GET_STATE':
      sendResponse({ ...state });
      break;

    case 'SET_SETTINGS':
      if (msg.delayMin !== undefined) state.delayMin = msg.delayMin;
      if (msg.delayMax !== undefined) state.delayMax = msg.delayMax;
      if (msg.autoNextPage !== undefined) state.autoNextPage = msg.autoNextPage;
      if (msg.batchLimit !== undefined) state.batchLimit = msg.batchLimit;
      saveState();
      sendResponse({ ok: true });
      break;

    case 'GET_CSV_LOG':
      sendResponse({ csvLog: state.csvLog });
      break;

    case 'CLEAR_LOG':
      state.csvLog = [];
      state.processedCount = 0;
      state.approvedCount = 0;
      state.notApprovedCount = 0;
      state.skippedCount = 0;
      saveState();
      broadcastState();
      sendResponse({ ok: true });
      break;

    // ---- From Scrappy content script ----

    case 'ROW_ACTION_DONE':
      if (!state.running) break;
      handleRowActionDone(msg);
      sendResponse({ ok: true });
      break;

    case 'ROW_SKIPPED':
      if (!state.running) break;
      state.skippedCount++;
      state.consecutiveSkips++;
      addCsvEntry(msg.asin, 'skipped', 'Row did not move after action');
      log(`ASIN ${msg.asin} stuck — skipped (${state.consecutiveSkips} consecutive)`);
      if (state.consecutiveSkips >= 10) {
        log('10 consecutive skips — refreshing Scrappy page to clear stale DOM...');
        state.consecutiveSkips = 0;
        state.skipSet = [];
        state.pendingRefresh = true;
        broadcastState();
        saveState();
        chrome.tabs.reload(state.scrappyTabId);
        // SCRAPPY_PAGE_READY will resume processing
        sendResponse({ ok: true });
        return;
      }
      broadcastState();
      saveState();
      if (state.running && !state.paused) {
        const gen = state.generation;
        const delay = getRandomDelay(1000, 2000);
        setTimeout(() => {
          if (!isStale(gen)) processNextRow();
        }, delay);
      }
      sendResponse({ ok: true });
      break;

    case 'NO_MORE_ROWS':
      if (!state.running) break;
      if (state.autoNextPage) {
        // Prevent infinite reload: if we just reloaded and got 0 rows again, stop
        if (state.emptyReloads >= 2) {
          log('No rows found after 2 reloads. All pages completed!');
          state.emptyReloads = 0;
          stopAutomation('All pages completed');
        } else {
          state.emptyReloads = (state.emptyReloads || 0) + 1;
          log(`Page exhausted. Reloading page (attempt ${state.emptyReloads})...`);
          state.skipSet = [];
          state.consecutiveSkips = 0;
          notifyScrappy('RELOAD_PAGE');
        }
      } else {
        log('Page exhausted. Auto-next disabled.');
        stopAutomation('Page completed');
      }
      sendResponse({ ok: true });
      break;

    case 'NEXT_PAGE_CLICKED':
      if (!state.running) break;
      state.skipSet = [];
      state.consecutiveSkips = 0;
      log('Navigated to next page. Waiting for load...');
      const genNext = state.generation;
      setTimeout(() => {
        if (!isStale(genNext) && state.running && !state.paused) processNextRow();
      }, 3000);
      sendResponse({ ok: true });
      break;

    case 'NO_NEXT_PAGE':
      log('All pages processed!');
      stopAutomation('All pages completed');
      sendResponse({ ok: true });
      break;

    case 'SCRAPPY_PAGE_READY':
      if (state.running) {
        log('Scrappy page loaded. Re-attaching...');
        state.scrappyTabId = sender.tab.id;
        state.pendingRefresh = false;
        notifyScrappy('SHOW_OVERLAY');
        notifyScrappy('SET_SKIP_LIST', { skipSet: state.skipSet });
        saveState();
        if (!state.paused && !state.waitingForUser) {
          const gen = state.generation;
          setTimeout(() => {
            if (!isStale(gen)) processNextRow();
          }, 3000);
        }
      }
      sendResponse({ ok: true });
      break;

    // ---- From Amazon content script ----

    case 'AMAZON_PAGE_RESULT':
      if (!state.running) break;
      clearAmazonTimeout();
      handleAmazonResult(msg.result, msg.asin, msg.reason);
      sendResponse({ ok: true });
      break;

    case 'AMAZON_LOGIN_REQUIRED':
      clearAmazonTimeout();
      handleLoginRequired();
      sendResponse({ ok: true });
      break;

    case 'AMAZON_CAPTCHA_DETECTED':
      clearAmazonTimeout();
      handleCaptcha();
      sendResponse({ ok: true });
      break;
  }

  return true;
});

// ---------- Tab Tracking ----------

chrome.tabs.onCreated.addListener((tab) => {
  if (!state.running) return;
  if (!state.amazonTabId && !state.existingAmazonTabIds.includes(tab.id)) {
    state.amazonTabId = tab.id;
    state.amazonTabOpenTime = Date.now();
    startAmazonTimeout();
    log(`Amazon tab opened: #${tab.id}`);
    saveState();
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!state.running) return;

  if (tabId === state.amazonTabId && changeInfo.status === 'complete') {
    if (tab.url && tab.url.includes('sellercentral.amazon.in')) {
      if (tab.url.includes('/signin') || tab.url.includes('/ap/signin') || tab.url.includes('identity-sso')) {
        handleLoginRequired();
        return;
      }

      log(`Amazon page loaded. Waiting for content check...`);
      const gen = state.generation;
      setTimeout(() => {
        if (isStale(gen) || !state.running) return;
        chrome.tabs.sendMessage(tabId, { action: 'CHECK_APPROVAL' }).catch(() => {
          setTimeout(() => {
            if (isStale(gen) || !state.running) return;
            chrome.tabs.sendMessage(tabId, { action: 'CHECK_APPROVAL' }).catch(() => {
              setTimeout(() => {
                if (isStale(gen) || !state.running) return;
                chrome.tabs.sendMessage(tabId, { action: 'CHECK_APPROVAL' }).catch(() => {
                  if (!isStale(gen) && state.running) {
                    log('ERROR: Failed to reach Amazon content script after 3 attempts.');
                    handleAmazonResult('error', state.currentAsin, 'Content script unreachable');
                  }
                });
              }, 3000);
            });
          }, 2000);
        });
      }, 1500);
    }
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (tabId === state.amazonTabId) {
    clearAmazonTimeout();
    state.amazonTabId = null;
    saveState();
    if (state.running && !state.paused && !state.waitingForUser) {
      log('Amazon tab was closed externally. Retrying current row...');
      const gen = state.generation;
      setTimeout(() => {
        if (!isStale(gen)) processNextRow();
      }, 2000);
    }
  }
  // Only treat Scrappy tab close as fatal if we're NOT in a pending refresh
  if (tabId === state.scrappyTabId && !state.pendingRefresh) {
    log('WARNING: Scrappy tab was closed!');
    stopAutomation('Scrappy tab closed');
  }
});

// ---------- Core Logic ----------

async function startAutomation() {
  const tabs = await chrome.tabs.query({ url: ['http://100.82.234.106:3000/*', 'http://localhost:3000/*'] });
  if (tabs.length === 0) {
    log('ERROR: Scrappy tab not found! Open the Scrappy page first.');
    return;
  }

  const amazonTabs = await chrome.tabs.query({ url: 'https://sellercentral.amazon.in/*' });
  state.existingAmazonTabIds = amazonTabs.map(t => t.id);
  if (amazonTabs.length > 0) {
    log(`Note: ${amazonTabs.length} existing Amazon tab(s) detected — will be ignored.`);
  }

  state.running = true;
  state.paused = false;
  state.waitingForUser = false;
  state.waitReason = '';
  state.scrappyTabId = tabs[0].id;
  state.amazonTabId = null;
  state.currentAsin = '';
  state.consecutiveSkips = 0;
  state.skipSet = [];
  state.sinceLastRefresh = 0;
  state.pendingRefresh = false;
  state.amazonTabOpenTime = 0;
  state.generation++; // new generation for this run

  broadcastState();
  saveState();
  log('Automation started!');

  notifyScrappy('SHOW_OVERLAY');
  setTimeout(() => processNextRow(), 1000);
}

function stopAutomation(reason) {
  clearAmazonTimeout();

  // Increment generation — ALL pending setTimeout callbacks become stale instantly
  state.generation++;

  state.running = false;
  state.paused = false;
  state.waitingForUser = false;
  state.pendingRefresh = false;
  state.currentAsin = '';

  // Close any open Amazon tab
  if (state.amazonTabId) {
    chrome.tabs.remove(state.amazonTabId).catch(() => {});
    state.amazonTabId = null;
  }

  broadcastState();
  saveState();
  log(`Automation stopped: ${reason || 'Unknown'}`);

  notifyScrappy('HIDE_OVERLAY');

  if (reason && reason.includes('completed')) {
    notifyScrappy('SHOW_ALERT', {
      title: 'Automation Complete!',
      message: `Processed: ${state.processedCount} | Approved: ${state.approvedCount} | Not Approved: ${state.notApprovedCount} | Skipped: ${state.skippedCount}`,
      type: 'success'
    });
  }
}

function processNextRow() {
  if (!state.running || state.paused || state.waitingForUser) return;

  if (state.batchLimit > 0 && state.processedCount >= state.batchLimit) {
    log(`Batch limit reached (${state.batchLimit}). Stopping.`);
    stopAutomation('Batch limit reached');
    return;
  }

  notifyScrappy('CLICK_AMZ_LINK', { skipSet: state.skipSet, lastProcessedAsin: state.lastProcessedAsin });
}

function handleRowActionDone(msg) {
  state.processedCount++;
  state.sinceLastRefresh++;
  state.consecutiveSkips = 0;
  state.emptyReloads = 0;
  state.lastProcessedAsin = msg.asin || state.currentAsin;

  if (msg.wasApproved) {
    state.approvedCount++;
    addCsvEntry(msg.asin || state.currentAsin, 'approved', msg.reason || 'Sell yours button found');
  } else {
    state.notApprovedCount++;
    addCsvEntry(msg.asin || state.currentAsin, 'not_approved', msg.reason || 'Request approval button found');
  }

  broadcastState();
  saveState();

  // Refresh Scrappy page every N ASINs
  if (state.sinceLastRefresh >= state.refreshInterval) {
    state.sinceLastRefresh = 0;
    state.skipSet = [];
    state.pendingRefresh = true;
    saveState();
    log(`Refreshing Scrappy page after ${state.refreshInterval} ASINs...`);
    chrome.tabs.reload(state.scrappyTabId);
    return; // SCRAPPY_PAGE_READY will resume
  }

  const gen = state.generation;
  const delay = getRandomDelay(1500, 3000);
  setTimeout(() => {
    if (!isStale(gen) && state.running && !state.paused) processNextRow();
  }, delay);
}

function handleAmazonResult(result, asin, reason) {
  if (!state.running) return;

  log(`ASIN ${asin || '?'}: ${result} — ${reason || ''}`);
  state.currentAsin = asin || '';

  const gen = state.generation;
  const delay = getRandomDelay(state.delayMin * 1000, state.delayMax * 1000);
  log(`Waiting ${Math.round(delay / 1000)}s before closing Amazon tab...`);

  setTimeout(() => {
    if (isStale(gen) || !state.running) return;

    if (state.amazonTabId) {
      chrome.tabs.remove(state.amazonTabId).catch(() => {});
      state.amazonTabId = null;
    }

    if (state.scrappyTabId) {
      chrome.tabs.update(state.scrappyTabId, { active: true }).catch(() => {});
    }

    setTimeout(() => {
      if (isStale(gen) || !state.running) return;

      if (result === 'approved') {
        notifyScrappy('CLICK_APPROVE', { asin, reason });
      } else {
        notifyScrappy('CLICK_NOT_APPROVED', { asin, reason });
      }
    }, 800);
  }, delay);
}

function handleLoginRequired() {
  log('ALERT: Amazon login/session expired! Pausing.');
  state.waitingForUser = true;
  state.waitReason = 'Amazon login required';
  state.paused = true;
  broadcastState();
  saveState();
  notifyScrappy('SHOW_ALERT', {
    title: 'Amazon Session Expired',
    message: 'Please log in to Amazon Seller Central in the open tab, then click "Resume" in the extension popup.',
    type: 'error'
  });
}

function handleCaptcha() {
  log('ALERT: Amazon CAPTCHA detected! Pausing for user.');
  state.waitingForUser = true;
  state.waitReason = 'CAPTCHA — solve it manually';
  state.paused = true;
  broadcastState();
  saveState();
  notifyScrappy('SHOW_ALERT', {
    title: 'CAPTCHA Detected',
    message: 'Amazon is showing a CAPTCHA. Solve it in the Amazon tab, then click "Resume" in the extension popup.',
    type: 'error'
  });
}

// ---------- Amazon Tab Timeout (5 min) ----------

function startAmazonTimeout() {
  clearAmazonTimeout();
  const gen = state.generation;
  amazonTimeoutTimer = setTimeout(() => {
    if (isStale(gen)) return;
    if (state.running && state.amazonTabId) {
      log('TIMEOUT: Amazon page did not load in 5 minutes!');
      chrome.tabs.remove(state.amazonTabId).catch(() => {});
      state.amazonTabId = null;
      stopAutomation('Amazon page timeout');
      notifyScrappy('SHOW_ALERT', {
        title: 'Internet Issue — Timeout',
        message: `Amazon page did not load within 5 minutes. Last ASIN attempted: ${state.currentAsin}. Check your internet connection and restart.`,
        type: 'error',
        big: true
      });
    }
  }, 5 * 60 * 1000);
}

function clearAmazonTimeout() {
  if (amazonTimeoutTimer) {
    clearTimeout(amazonTimeoutTimer);
    amazonTimeoutTimer = null;
  }
}

// ---------- CSV Log ----------

function addCsvEntry(asin, status, reason) {
  state.csvLog.push({
    asin: asin || 'unknown',
    status,
    reason: reason || '',
    timestamp: new Date().toISOString()
  });
  saveState();
}

// ---------- Helpers ----------

function getRandomDelay(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function notifyScrappy(action, data) {
  if (!state.scrappyTabId) return;
  chrome.tabs.sendMessage(state.scrappyTabId, { action, ...data }).catch(() => {});
}

function broadcastState() {
  chrome.runtime.sendMessage({ action: 'STATE_UPDATE', state: { ...state } }).catch(() => {});
  notifyScrappy('STATE_UPDATE', { state: { ...state } });
}

function log(message) {
  const ts = new Date().toLocaleTimeString();
  const entry = `[${ts}] ${message}`;
  console.log(entry);
  chrome.runtime.sendMessage({ action: 'LOG', message: entry }).catch(() => {});
  notifyScrappy('LOG', { message: entry });
}
